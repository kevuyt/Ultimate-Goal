exports.JavaLexer = require('java/js/java/JavaLexer').JavaLexer;
exports.JavaListener = require('java/js/java/JavaListener').JavaListener;
exports.JavaParser = require('java/js/java/JavaParser').JavaParser;